<template>
  <div>
      <img src="../assets/04.playlists.jpg" alt="">
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>